#ifndef __BSP_MODBUS_H_
#define __BSP_MODBUS_H_

#include "modbus_data.h"
#include "modbus_mapchart.h"
#include "bsp_Rs485.h"
#include <stdlib.h> 

extern volatile uint16_t GM3085E_RxLen;
extern uint8_t GM3085E_RxBuf[GM3085E_RX_BUF_SIZE];
extern rs485_data_t gm3085e_dev;//�������rs485


typedef struct modbus_device{
	uint8_t modbus_addr;//����modbus�ӻ���ַ
	int (*ModbusRespond)(uint8_t *respond, uint16_t len);//modbus��Ӧ����
	p_rs485_data physicalDev; //����ͨ���豸
}modbus_device, *p_modbus_device;

extern modbus_device modbus_dev;

void Modbus_Init(void);

#endif

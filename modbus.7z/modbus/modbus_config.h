#ifndef __MODBUS_CONFIG_H_
#define __MODBUS_CONFIG_H_

#include <stdlib.h> 
#include "main.h"

#define MAX_COIL   0
#define MAX_DI     0
#define MAX_IR     5000
#define MAX_HR     2000

#define SATRT_COIL 	 0
#define SATRT_DI     10000
#define SATRT_IR     30000
#define SATRT_HR     40000

extern uint8_t  g_coil[MAX_COIL];
extern uint8_t  g_di[MAX_DI];
extern uint16_t g_ir[MAX_IR];
extern uint16_t g_hr[MAX_HR];


extern int ecc;


#endif

#ifndef __MODBUS_DATA_H_
#define __MODBUS_DATA_H_

#include "main.h"
#include "cmsis_os.h"
#include "modbus_mapchart.h"
#include <stdint.h>
#include <string.h>

extern modbus_mapchart_device modbus_mapchart;

uint16_t Modbus_CRC16_Table(uint8_t *buf, uint16_t len);
int JuegeVaildData(uint8_t *rxbuf, uint16_t rxlen);
int PackExceptionResponse(uint8_t *rxbuf, uint8_t *txbuf, uint8_t exception_code);
int PackRespondReadCoil(uint8_t *rxbuf, uint8_t* txbuf);//0x01
int PackRespondReadDiscreteInputs(uint8_t *rxbuf, uint8_t *txbuf);//0x02
int PackRespondReadHregisters(uint8_t *rxbuf, uint8_t* txbuf);//0x03
int PackRespondReadInputRegisters(uint8_t *rxbuf, uint8_t *txbuf);//0x04
int PackRespondWriteCoil(uint8_t *rxbuf, uint8_t *txbuf);//0x05
int PackRespondWriteHregisters(uint8_t *rxbuf, uint8_t* txbuf);//0x06
int PackRespondWriteMoreHregisters(uint8_t *rxbuf, uint8_t* txbuf);//0x10
int PackRespondWriteMoreCoils(uint8_t *rxbuf, uint8_t *txbuf);//0x0f
int ModbusSlaveDispatch(uint8_t* rxbuf, uint16_t rxlen, uint8_t* txbuf, uint8_t slave_addr);

#endif

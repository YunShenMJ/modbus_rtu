#include "bsp_modbus.h"

int ModbusRespond(uint8_t *respond, uint16_t len)
{
	if((发送函数)(respond, len) ==(成功返回)) return 0;
	else return -1;
}

modbus_device modbus_dev={0x00, ModbusRespond, &gm3085e_dev};//ʵ��modbus�豸


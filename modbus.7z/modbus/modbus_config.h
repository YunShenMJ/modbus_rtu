#ifndef __MODBUS_CONFIG_H_
#define __MODBUS_CONFIG_H_

#include <stdlib.h> 
#include "main.h"

#define MAX_COIL   1
#define MAX_DI     1
#define MAX_IR     5000
#define MAX_HR     2

#define SATRT_COIL 	 0
#define SATRT_DI     10000
#define SATRT_IR     46500
#define SATRT_HR     40997

extern uint8_t  g_coil[MAX_COIL];
extern uint8_t  g_di[MAX_DI];
extern uint16_t g_ir[MAX_IR];
extern uint16_t g_hr[MAX_HR];


extern int ecc;


#endif

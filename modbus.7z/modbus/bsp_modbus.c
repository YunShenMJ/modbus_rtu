#include "bsp_modbus.h"

int ModbusRespond(uint8_t *respond, uint16_t len)
{
	if(GM3085_Send_IT(respond, len) ==STATUS_SUCCESS) return 0;
	else return -1;
}

modbus_device modbus_dev={0x00, ModbusRespond, &gm3085e_dev};//ʵ��modbus�豸


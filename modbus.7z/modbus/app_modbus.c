#include "app_modbus.h"


void ModbusPollingSystem(void *argument)
{
	(void)argument;
	p_modbus_device dev =&modbus_dev;//ȡ��modbus�豸
	dev->modbus_addr =0x32;//���ôӻ���ַ
	static uint8_t txbuf[32] ={0};
	int modbus_data;
	
	for(;;)
	{
		if(dev->physicalDev->GM3085E_RxFlag ==1 ||GM3085E_RxLen >0)
		{
			modbus_data = ModbusSlaveDispatch(GM3085E_RxBuf, GM3085E_RxLen, txbuf, dev->modbus_addr);
			if(modbus_data >4)
			{
				dev->ModbusRespond(txbuf, modbus_data);
				dev->physicalDev->GM3085E_RxFlag =0;
				GM3085E_RxLen =0;
			}
		}else{
			
		}
		
	}
}

